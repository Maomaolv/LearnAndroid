package com.example.avjindersinghsekhon.minimaltodo;

import android.app.Application;

public class AnalyticsApplication extends Application {

    //todo: to track the usage using google platform

}
